export { default } from "./FAQs";
