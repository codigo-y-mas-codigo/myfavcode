# GFormulario

A Pen created on CodePen.

Original URL: [https://codepen.io/luisangelmaciel/pen/GRaYwVz](https://codepen.io/luisangelmaciel/pen/GRaYwVz).

