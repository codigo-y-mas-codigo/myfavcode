 <script type="application/ld+json">
  {
   "@context": "https://schema.org",
   "@type": "DigitalDocument",
   "name": "EC0360-PEDAGOGIA-VOLANTE",
   "description": "Calendario escolar 2022-2023",
   "url": "https://luisangelmaciel.github.io/luisangelmaciel/EC0360-PEDAGOGIA-VOLANTE.pdf",
   "encodingFormat": "application/pdf",
   "fileFormat": "PDF",
   "author": {
    "@type": "Person",
    "name": "Luis Angel Maciel"
   },
   "publisher": {
    "@type": "Organization",
    "name": "Luis Angel Maciel",
    "url": "https://luisangelmaciel.github.io"
   },
   "datePublished": "2022-01-01"
  }
 </script>https://codepen.io/luisangelmaciel/pen/vEBONaO?editors=1000