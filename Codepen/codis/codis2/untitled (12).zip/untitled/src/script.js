document.addEventListener("DOMContentLoaded", () => {
 const slides = document.querySelectorAll(".survey-slide");
 const prevBtn = document.getElementById("prev-btn");
 const nextBtn = document.getElementById("next-btn");
 const progressBarFill = document.querySelector(".progress-fill");
 const slideCounter = document.getElementById("slide-counter");
 const clearProgressBtn = document.getElementById("clear-progress-btn");

 let currentSlideIndex = 0;
 const totalSlides = slides.length;
 const localStorageDataKey = "tarotSurveyProgress";
 const localStorageIndexKey = "lastSlideIndex";

 // Load progress from Local Storage
 let surveyData = {};
 const savedData = localStorage.getItem(localStorageDataKey);
 if (savedData) {
  try {
   surveyData = JSON.parse(savedData);
  } catch (e) {
   console.error("Error parsing saved survey data:", e);
   // Clear corrupted data
   localStorage.removeItem(localStorageDataKey);
   localStorage.removeItem(localStorageIndexKey);
  }
 }

 // Load last visited slide index
 const savedIndex = localStorage.getItem(localStorageIndexKey);
 if (savedIndex !== null && savedIndex !== undefined) {
  const parsedIndex = parseInt(savedIndex, 10);
  if (!isNaN(parsedIndex) && parsedIndex >= 0 && parsedIndex < totalSlides) {
   currentSlideIndex = parsedIndex;
  }
 }

 // --- Core Functions ---

 function showSlide(index) {
  // Hide all slides
  slides.forEach((slide) => {
   slide.classList.remove("active-slide");
   slide.style.display = "none"; // Explicitly hide
  });

  // Show the current slide
  if (slides[index]) {
   slides[index].style.display = "block"; // Explicitly show
   slides[index].classList.add("active-slide");

   // Pre-fill answers for the current slide
   prefillAnswer(index);
   // Update conditional questions visibility
   updateConditionalQuestions(index);

   // Save the current index
   localStorage.setItem(localStorageIndexKey, index.toString());
  }

  // Update UI
  updateProgressBar();
  updateButtonStates();
  updateSlideCounter();
 }

 function updateProgressBar() {
  // Calculate progress percentage (exclude intro from question count for progress?)
  // Let's calculate based on getting *through* question slides for simplicity here.
  // The progress bar represents completion towards the *end* slide.
  const progressPercentage = (currentSlideIndex / (totalSlides - 1)) * 100;
  progressBarFill.style.width = `${progressPercentage}%`;
 }

 function updateButtonStates() {
  // Disable Previous button on the first slide (index 0)
  prevBtn.disabled = currentSlideIndex === 0;

  // Disable Next button on the last slide
  nextBtn.disabled = currentSlideIndex === totalSlides - 1;

  // Additional: Could add logic here to disable next if required fields on the current slide are not filled
  // This requires checking specific input types (radio, select usually, text/textarea if marked required).
  // For this example, we'll keep it simple and allow skipping unless it's the very last slide.
  const currentSlide = slides[currentSlideIndex];
  const requiredInputs = currentSlide.querySelectorAll(
   "input[required], select[required], textarea[required]"
  );
  let allRequiredFilled = true;

  if (
   requiredInputs.length > 0 &&
   currentSlide.dataset.slideType !== "intro" &&
   currentSlide.dataset.slideType !== "conclusion"
  ) {
   // Only check required fields on question slides
   requiredInputs.forEach((input) => {
    if (input.type === "radio" || input.type === "checkbox") {
     // For radio/checkbox, check if any with the same name are checked
     const groupName = input.name;
     if (!document.querySelector(`input[name="${groupName}"]:checked`)) {
      allRequiredFilled = false;
     }
    } else if (input.value.trim() === "") {
     allRequiredFilled = false;
    }
   });
   // nextBtn.disabled = !allRequiredFilled && currentSlideIndex < totalSlides - 1;
   // Decided against disabling next based on required for simple demo, user can skip if they want.
   // Reverting to original logic: only disable on the very last slide.
   nextBtn.disabled = currentSlideIndex === totalSlides - 1;
  }
 }

 function updateSlideCounter() {
  // Only show counter for question slides, not intro/conclusion
  const slideType = slides[currentSlideIndex].dataset.slideType;
  if (slideType === "intro" || slideType === "conclusion") {
   slideCounter.textContent = ""; // Hide counter
  } else {
   // Assuming question slides are indices > 0 and < totalSlides - 1
   // Adjust counting if intro/conclusion logic changes
   const questionSlides = Array.from(slides).filter(
    (slide) => slide.dataset.questionKey
   );
   const currentQuestionIndex = questionSlides.indexOf(
    slides[currentSlideIndex]
   );
   if (currentQuestionIndex !== -1) {
    slideCounter.textContent = `Pregunta ${currentQuestionIndex + 1} de ${
     questionSlides.length
    }`;
   } else {
    slideCounter.textContent = "";
   }
  }
 }

 function collectAnswer(slideIndex) {
  const slide = slides[slideIndex];
  const questionKey = slide.dataset.questionKey;

  if (!questionKey) return; // Don't collect from intro/conclusion

  // Get all relevant input types within the slide
  const inputs = slide.querySelectorAll("input, select, textarea");
  const slideAnswers = {};

  inputs.forEach((input) => {
   const name = input.name;
   const type = input.type;

   // Skip the hidden textareas used for 'Other' options if they are empty
   if (name && name.endsWith("_other_text") && input.value.trim() === "") {
    return;
   }

   if (type === "radio") {
    if (input.checked) {
     slideAnswers[name] = input.value;
    }
   } else if (type === "checkbox") {
    if (!slideAnswers[name]) {
     slideAnswers[name] = [];
    }
    if (input.checked) {
     slideAnswers[name].push(input.value);
    }
    // Handle the linked textarea for 'Other' checkbox
    if (
     input.value.endsWith("_other") &&
     slide.querySelector(`textarea[name="${name}_other_text"]`)
    ) {
     const otherTextarea = slide.querySelector(
      `textarea[name="${name}_other_text"]`
     );
     if (input.checked && otherTextarea && otherTextarea.value.trim() !== "") {
      // Append the text value if the checkbox is checked and textarea is not empty
      slideAnswers[name].push(otherTextarea.value.trim());
     } else if (!input.checked && otherTextarea) {
      // If the 'Other' checkbox is unchecked, remove the specific 'other_[name]' value
      // This handles cases where they type text but then uncheck "Other"
      const otherVal = `other_${name.replace(/s$/, "")}`; // e.g., motivation -> other_motivation
      slideAnswers[name] = slideAnswers[name].filter(
       (val) => val !== input.value && val !== otherVal
      );
     }
    }
   } else if (type === "select-one" || type === "textarea" || type === "text") {
    // Handle linked textarea for 'Other' radio options
    if (name.endsWith("_other_text")) {
     // This textarea is linked to a radio button 'other_[radio_name]'
     // The value will be stored under its own name, which is fine.
     if (input.value.trim() !== "") {
      slideAnswers[name] = input.value.trim();
     } else {
      // Ensure empty 'Other' text is not saved if the radio is not selected
      const radioName = name.replace("_other_text", "");
      const otherRadio = slide.querySelector(
       `input[name="${radioName}"][value="other_${radioName.replace(
        /s$/,
        ""
       )}"]`
      ); // e.g., most_used_spread -> other_most_used_spread
      if (!otherRadio || !otherRadio.checked) {
       delete slideAnswers[name]; // Remove if not selected
      } else {
       slideAnswers[name] = ""; // Save as empty string if radio is checked but text is empty
      }
     }
    } else if (input.value.trim() !== "" || input.type === "select-one") {
     // Save select even if empty, text/textarea only if not empty
     slideAnswers[name] = input.value.trim();
    } else {
     // If text/textarea is empty and not required, don't save its key
     delete slideAnswers[name];
    }
   }
   // Add other input types if needed
  });

  // Store answers under the question key
  surveyData[questionKey] = slideAnswers;

  // Save to Local Storage
  localStorage.setItem(localStorageDataKey, JSON.stringify(surveyData));
 }

 function prefillAnswer(slideIndex) {
  const slide = slides[slideIndex];
  const questionKey = slide.dataset.questionKey;

  if (!questionKey || !surveyData[questionKey]) return; // No data to prefill

  const slideData = surveyData[questionKey];
  const inputs = slide.querySelectorAll("input, select, textarea");

  inputs.forEach((input) => {
   const name = input.name;
   const type = input.type;
   const savedValue = slideData[name];

   // Skip the hidden textareas used for 'Other' options initially - they are handled via the linked radio/checkbox
   if (name && name.endsWith("_other_text")) {
    return;
   }

   if (savedValue !== undefined) {
    if (type === "radio") {
     if (input.value === savedValue) {
      input.checked = true;
      // If this is an 'Other' radio, also prefill its textarea
      if (
       input.value.startsWith("other_") &&
       slide.querySelector(`textarea[name="${name}_other_text"]`)
      ) {
       const otherTextarea = slide.querySelector(
        `textarea[name="${name}_other_text"]`
       );
       if (slideData[`${name}_other_text`] !== undefined) {
        otherTextarea.value = slideData[`${name}_other_text`];
       }
      }
     } else {
      input.checked = false;
     }
    } else if (type === "checkbox") {
     if (Array.isArray(savedValue)) {
      if (savedValue.includes(input.value)) {
       input.checked = true;
       // If this is an 'Other' checkbox, also prefill its textarea
       if (
        input.value.endsWith("_other") &&
        slide.querySelector(`textarea[name="${name}_other_text"]`)
       ) {
        const otherTextarea = slide.querySelector(
         `textarea[name="${name}_other_text"]`
        );
        // Find the custom text value associated with this checkbox
        const customOtherValue = savedValue.find(
         (val) => !input.value.startsWith("other_") && val !== input.value
        ); // Find a value that isn't the specific checkbox value
        // A better approach is needed here if multiple 'other' textareas could exist per question key.
        // Assuming only ONE 'other_text' area per question key that might link to ONE '_other' checkbox/radio value.
        // Let's prefill the textarea directly from savedData if it exists under its own key.
        if (slideData[`${name}_other_text`] !== undefined) {
         otherTextarea.value = slideData[`${name}_other_text`];
        }
       }
      } else {
       input.checked = false;
      }
     }
    } else if (
     type === "select-one" ||
     type === "textarea" ||
     type === "text"
    ) {
     input.value = savedValue;
    }
    // Add other input types
   } else {
    // If no saved value, ensure input is cleared/unchecked
    if (type === "radio" || type === "checkbox") {
     input.checked = false;
    } else if (type === "select-one") {
     input.value = ""; // Reset select to default option
    } else if (type === "textarea" || type === "text") {
     input.value = ""; // Clear text inputs
    }
   }
  });

  // Also handle prefilling for the linked textarea if it exists and has saved data
  inputs.forEach((input) => {
   if (input.name && input.name.endsWith("_other_text")) {
    const textareaName = input.name;
    if (slideData[textareaName] !== undefined) {
     input.value = slideData[textareaName];
    } else {
     input.value = "";
    }
   }
  });
 }

 // Function to hide/show questions based on previous answers
 function updateConditionalQuestions(slideIndex) {
  const slide = slides[slideIndex];
  const dependentQuestions = slide.querySelectorAll(
   ".question[data-dependent-on]"
  );

  dependentQuestions.forEach((q) => {
   const dependentOn = q.dataset.dependentOn; // e.g., 'distance_readings'
   const dependentValues = q.dataset.dependentValue.split(","); // e.g., ['main', 'combined']

   // Find the question slide that contains the input for 'dependentOn'
   // This is a bit complex as it requires looking at previous slides.
   // A simpler approach for this structure is to assume dependency is based on
   // an input *within this same slide* or a *previous slide's collected data*.
   // Let's simplify and assume it depends on the *collected data* from a previous slide's key.

   let dependencyMet = false;
   // Find the data for the key this question depends on
   const dependencyData = surveyData[dependentOn]; // dependentOn is actually the question key from a PREVIOUS slide

   if (dependencyData) {
    // Assuming the dependency is on a specific input name *within* that question key's data
    // The dataset.dependent-on is actually the *input name*, not the *question key*
    // Let's correct the HTML data attribute definition to point to the INPUT NAME.
    // e.g., data-dependent-on="distance_readings" where 'distance_readings' is an input name.
    // We need to find which QUESTION KEY holds this input name.
    // This requires iterating through surveyData keys to find the one containing the input name.

    // A more robust way: Store dependencies centrally or link question keys to input names.
    // Simpler approach for this demo: Assume dependent-on refers to an INPUT NAME
    // collected from a *previous* slide, and check its value directly in surveyData.
    // This needs careful mapping in HTML. Let's refine HTML data attributes:
    // data-dependent-on-key="digital_practice" (The key where the input lives)
    // data-dependent-on-input="distance_readings" (The input name)
    // data-dependent-value="main,combined" (Values of that input)

    const dependentOnKey = q.dataset.dependentOnKey; // e.g., 'digital_practice'
    const dependentOnInputName = q.dataset.dependentOnInput; // e.g., 'distance_readings'

    if (
     surveyData[dependentOnKey] &&
     surveyData[dependentOnKey][dependentOnInputName] !== undefined
    ) {
     const actualValue = surveyData[dependentOnKey][dependentOnInputName]; // Value of the input

     if (Array.isArray(actualValue)) {
      // If the dependent input is a checkbox (array of values)
      dependencyMet = dependentValues.some((val) => actualValue.includes(val));
     } else {
      // If the dependent input is radio, select, text etc.
      dependencyMet = dependentValues.includes(actualValue);
     }
    }
   } else {
    // If the dependency data hasn't even been collected yet (user skipped or is on a very early slide)
    dependencyMet = false;
   }

   // Apply display based on dependency met
   if (dependencyMet) {
    q.style.display = "block"; // Show the question
    // Make inputs required if the question is shown (optional but good for data)
    q.querySelectorAll("input, select, textarea").forEach((input) => {
     if (input.dataset.originalRequired !== "false") {
      // Check if it wasn't originally false
      input.required = true;
     }
    });
   } else {
    q.style.display = "none"; // Hide the question
    // Make inputs NOT required if the question is hidden
    q.querySelectorAll("input, select, textarea").forEach((input) => {
     // Store original required state? Or just disable required
     input.required = false;
     // Clear any potentially pre-filled answers in hidden questions
     // This prevents saving data for questions that weren't visible/answered
     const inputName = input.name;
     if (
      surveyData[questionKey] &&
      surveyData[questionKey][inputName] !== undefined
     ) {
      delete surveyData[questionKey][inputName];
      localStorage.setItem(localStorageDataKey, JSON.stringify(surveyData)); // Re-save data after clearing
     }
    });
   }
  });
 }

 // --- Event Listeners ---

 nextBtn.addEventListener("click", () => {
  // Validate current slide before moving? (Optional)
  // For this demo, we allow skipping most questions

  // Collect answer(s) from the current slide BEFORE moving
  collectAnswer(currentSlideIndex);

  if (currentSlideIndex < totalSlides - 1) {
   currentSlideIndex++;
   showSlide(currentSlideIndex);
  }
 });

 prevBtn.addEventListener("click", () => {
  // No need to collect data on 'Previous' click as it was saved on 'Next'
  if (currentSlideIndex > 0) {
   currentSlideIndex--;
   showSlide(currentSlideIndex);
  }
 });

 // Optional: Add a clear progress button listener
 if (clearProgressBtn) {
  clearProgressBtn.addEventListener("click", () => {
   if (confirm("¿Estás seguro de que quieres borrar todo tu progreso?")) {
    localStorage.removeItem(localStorageDataKey);
    localStorage.removeItem(localStorageIndexKey);
    surveyData = {}; // Clear in memory data
    currentSlideIndex = 0; // Reset to start
    showSlide(currentSlideIndex); // Show the first slide
    alert("Progreso borrado.");
   }
  });
 }

 // --- Initialization ---
 // Show the initial slide (either first or resumed)
 showSlide(currentSlideIndex);

 // Initial update of conditional questions in case we resume on a slide with dependencies
 updateConditionalQuestions(currentSlideIndex);

 // Add event listeners to inputs within the active slide to update conditional questions visibility IF the dependency is within the SAME slide
 // This is only needed if a question in slide N depends on an answer in slide N.
 // If dependencies are ONLY on *previous* slides, updateConditionalQuestions is sufficient on showSlide.
 // For simplicity, let's assume dependencies are only on *previous* slides' data.
 // If you add same-slide dependencies, you'd need listeners here.
});
