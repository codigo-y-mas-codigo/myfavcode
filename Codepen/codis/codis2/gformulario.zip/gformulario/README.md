# GFormulario

A Pen created on CodePen.

Original URL: [https://codepen.io/luisangelmaciel/pen/OJYBEBO](https://codepen.io/luisangelmaciel/pen/OJYBEBO).

