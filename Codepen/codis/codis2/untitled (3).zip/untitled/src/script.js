document.addEventListener("DOMContentLoaded", () => {
 let data = [
  {
   titulo: "Guía de Uso para Crear Contribuciones en LinkedIn",
   prompt:
    "Escribe una contribución de alta calidad para obtener la insignia de Top Marketing Digital en LinkedIn.",
   guia_de_uso: "Instrucciones de la guia de uso",
   fecha: "2023-10-01"
  }
 ];

 const titlesList = document.getElementById("titles-list");
 const promptSection = document.getElementById("prompt");
 const guiaDeUsoSection = document.getElementById("guia-de-uso");
 const searchInput = document.getElementById("search");
 const toast = document.getElementById("toast");
 const modal = document.getElementById("modal");
 const editModal = document.getElementById("edit-modal");
 const closeBtn = document.querySelector(".close-btn");
 const dataForm = document.getElementById("data-form");
 const editDataForm = document.getElementById("edit-data-form");
 const addDataBtn = document.getElementById("add-data-btn");
 const downloadDataBtn = document.getElementById("download-data-btn");
 const darkModeBtn = document.getElementById("dark-mode-btn");

 let currentIndex = null;

 // Inicializar editores de texto enriquecido
 const promptEditor = new Quill("#prompt-editor", { theme: "snow" });
 const guiaDeUsoEditor = new Quill("#guia-de-uso-editor", { theme: "snow" });
 const editPromptEditor = new Quill("#edit-prompt-editor", { theme: "snow" });
 const editGuiaDeUsoEditor = new Quill("#edit-guia-de-uso-editor", {
  theme: "snow"
 });

 function renderTitles(data) {
  titlesList.innerHTML = "";
  data.forEach((item, index) => {
   const li = document.createElement("li");
   li.textContent = item.titulo;
   li.addEventListener("click", () => showContent(index));
   li.addEventListener("dblclick", () => showEditButtons(index));
   titlesList.appendChild(li);
  });
 }

 function showContent(index) {
  const item = data[index];
  promptSection.innerHTML = item.prompt;
  guiaDeUsoSection.innerHTML = item.guia_de_uso;
 }

 function showEditButtons(index) {
  const item = data[index];
  const li = titlesList.children[index];

  // Remove existing buttons if any
  while (li.firstChild && li.firstChild.tagName === "BUTTON") {
   li.removeChild(li.firstChild);
  }

  const editBtn = document.createElement("button");
  editBtn.textContent = "Editar";
  editBtn.addEventListener("click", (event) => {
   event.stopPropagation();
   openEditModal(index);
  });

  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "Borrar";
  deleteBtn.addEventListener("click", (event) => {
   event.stopPropagation();
   if (confirm("¿Estás seguro de que deseas eliminar este elemento?")) {
    deleteData(index);
   }
  });

  li.insertBefore(editBtn, li.firstChild);
  li.insertBefore(deleteBtn, li.firstChild);
 }

 function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
   showToast();
  });
 }

 function showToast() {
  toast.classList.add("show");
  setTimeout(() => {
   toast.classList.remove("show");
  }, 2000);
 }

 promptSection.addEventListener("click", () => {
  copyToClipboard(promptSection.textContent);
 });

 guiaDeUsoSection.addEventListener("click", () => {
  copyToClipboard(guiaDeUsoSection.textContent);
 });

 searchInput.addEventListener("input", (event) => {
  const query = event.target.value.toLowerCase();
  const filteredData = data.filter((item) =>
   item.titulo.toLowerCase().includes(query)
  );
  renderTitles(filteredData);
 });

 function addNewData(newData) {
  newData.fecha = new Date().toISOString().split("T")[0];
  data.push(newData);
  localStorage.setItem("linkedinData", JSON.stringify(data));
  renderTitles(data);
 }

 function openEditModal(index) {
  currentIndex = index;
  const item = data[index];
  document.getElementById("edit-titulo").value = item.titulo;
  editPromptEditor.root.innerHTML = item.prompt;
  editGuiaDeUsoEditor.root.innerHTML = item.guia_de_uso;
  editModal.style.display = "block";
 }

 function editData(index, updatedData) {
  updatedData.fecha = data[index].fecha; // Mantener la fecha original
  data[index] = updatedData;
  localStorage.setItem("linkedinData", JSON.stringify(data));
  renderTitles(data);
  showContent(index);
 }

 function deleteData(index) {
  data.splice(index, 1);
  localStorage.setItem("linkedinData", JSON.stringify(data));
  renderTitles(data);
 }

 addDataBtn.addEventListener("click", () => {
  modal.style.display = "block";
 });

 downloadDataBtn.addEventListener("click", () => {
  const jsonData = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonData], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "linkedin_data.json";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
 });

 darkModeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
 });

 closeBtn.addEventListener("click", () => {
  modal.style.display = "none";
  editModal.style.display = "none";
 });

 window.addEventListener("click", (event) => {
  if (event.target === modal || event.target === editModal) {
   modal.style.display = "none";
   editModal.style.display = "none";
  }
 });

 dataForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const newData = {
   titulo: event.target.titulo.value,
   prompt: promptEditor.root.innerHTML,
   guia_de_uso: guiaDeUsoEditor.root.innerHTML
  };
  addNewData(newData);
  modal.style.display = "none";
  dataForm.reset();
  promptEditor.root.innerHTML = "";
  guiaDeUsoEditor.root.innerHTML = "";
 });

 editDataForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const updatedData = {
   titulo: event.target.titulo.value,
   prompt: editPromptEditor.root.innerHTML,
   guia_de_uso: editGuiaDeUsoEditor.root.innerHTML
  };
  editData(currentIndex, updatedData);
  editModal.style.display = "none";
  editDataForm.reset();
  editPromptEditor.root.innerHTML = "";
  editGuiaDeUsoEditor.root.innerHTML = "";
 });

 renderTitles(data);

 // Cargar data desde localStorage si existe
 const storedData = localStorage.getItem("linkedinData");
 if (storedData) {
  data = JSON.parse(storedData);
  renderTitles(data);
 }
});
